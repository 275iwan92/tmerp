<div class="max-w-xl mx-auto bg-slate-900 text-white rounded-3xl p-6 shadow-2xl border border-slate-800">
    <div class="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
        <div>
            <span class="text-xs font-mono text-emerald-400 uppercase tracking-widest font-semibold">ESS Mobile Presensi</span>
            <h2 class="text-xl font-bold text-white">Geofencing & Face AI</h2>
        </div>
        <span class="px-3 py-1 bg-emerald-500/20 text-emerald-300 text-xs rounded-full border border-emerald-500/30">
            GPS Live Active
        </span>
    </div>

    <!-- Geofencing Radar Box -->
    <div class="bg-slate-800/80 rounded-2xl p-4 border border-slate-700 mb-6">
        <div class="flex justify-between items-center mb-2">
            <span class="text-xs text-slate-400">Jarak ke Kantor Panji Suroso:</span>
            <span class="text-sm font-bold font-mono {{ $isInRadius ? 'text-emerald-400' : 'text-rose-400' }}">
                {{ $distanceMeters }} Meter
            </span>
        </div>
        <div class="w-full bg-slate-700 h-2 rounded-full overflow-hidden">
            <div class="h-full {{ $isInRadius ? 'bg-emerald-500' : 'bg-rose-500' }}" style="width: {{ min(100, ($distanceMeters / 50) * 100) }}%"></div>
        </div>
        <p class="text-[11px] mt-2 {{ $isInRadius ? 'text-emerald-400' : 'text-rose-400' }}">
            {{ $isInRadius ? '✔ Di dalam radius presensi resmi (< 50 meter)' : '⚠ Di luar radius (Membutuhkan Approval HR)' }}
        </p>
    </div>

    <!-- Face Biometric Scanner Mockup -->
    <div class="relative bg-slate-950 rounded-2xl h-56 flex flex-col items-center justify-center border-2 border-dashed {{ $faceVerified ? 'border-emerald-500' : 'border-indigo-500' }} mb-6 overflow-hidden">
        <div class="w-28 h-36 rounded-full border-2 border-indigo-400/60 flex items-center justify-center relative">
            <div class="w-full h-1 bg-indigo-500 absolute top-1/2 animate-pulse"></div>
            <span class="text-3xl">👤</span>
        </div>
        <div class="mt-3 text-center">
            <p class="text-xs font-semibold {{ $faceVerified ? 'text-emerald-400' : 'text-slate-300' }}">
                {{ $faceVerified ? 'Biometrik Wajah Terverifikasi (99.4% Match)' : 'Posisikan wajah Anda di dalam frame' }}
            </p>
            <button type="button" wire:click="$set('faceVerified', true)" class="mt-2 px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-xs rounded-lg font-medium transition">
                Simulasikan Liveness Scan
            </button>
        </div>
    </div>

    <!-- Submit Button -->
    <button type="button" wire:click="submitClockIn" class="w-full py-4 bg-emerald-600 hover:bg-emerald-500 active:scale-[0.98] text-white font-bold rounded-2xl shadow-lg shadow-emerald-900/30 transition">
        KIRIM PRESENSI MASUK
    </button>
</div>

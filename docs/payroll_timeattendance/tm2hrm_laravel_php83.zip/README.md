# TM2HRM ERP — PT. TELASIH MAKMUR (MALANG)
## Stack: PHP 8.3+ | Laravel | Livewire | Filament | Tailwind CSS

Aplikasi Enterprise Resource Planning (ERP) HRIS, Presensi Multi-Shift, ESS Mobile GPS Geofencing & Biometrik Wajah, serta Payroll Engine terintegrasi Regulasi Ketenagakerjaan Indonesia (BPJS TK, BPJS Kes, PPh 21 TER PP 58/2023, Lembur Depnaker Kepmenaker 102/2004, dan e-Payslip Tanda Tangan Elektronik UU ITE).

---

### Persyaratan Sistem (Server Prerequisites)
- Ubuntu Server 22.04 LTS / 24.04 LTS
- PHP 8.3 atau lebih baru (`php8.3-cli`, `php8.3-fpm`, `php8.3-mysql`, `php8.3-mbstring`, `php8.3-xml`, `php8.3-bcmath`, `php8.3-curl`, `php8.3-gd`, `php8.3-zip`, `php8.3-intl`)
- MySQL 8.0+ / MariaDB 10.6+
- Composer 2.x
- Node.js 18+ & NPM (untuk build Tailwind CSS & Vite asset)

---

### Cara Instalasi & Deploy Cepat (Quick Start)

1. **Jalankan Skrip Instalasi Otomatis:**
   ```bash
   chmod +x deploy_ubuntu.sh
   ./deploy_ubuntu.sh
   ```

2. **Atau Jalankan Manual Langkah-demi-Langkah:**
   ```bash
   # 1. Salin konfigurasi environment
   cp .env.example .env

   # 2. Sesuaikan konfigurasi database MySQL di .env
   nano .env

   # 3. Install dependency PHP
   composer install --optimize-autoloader

   # 4. Generate application key
   php artisan key:generate

   # 5. Jalankan migrasi & database seeding (Data PT Telasih Makmur)
   php artisan migrate:fresh --seed

   # 6. Install asset frontend (Tailwind & Vite)
   npm install
   npm run build

   # 7. Symlink storage dokumen lampiran
   php artisan storage:link

   # 8. Jalankan local server
   php artisan serve --port=8000
   ```

3. **Akses Dashboard Filament HRIS:**
   Buka di browser: `http://localhost:8000/admin`

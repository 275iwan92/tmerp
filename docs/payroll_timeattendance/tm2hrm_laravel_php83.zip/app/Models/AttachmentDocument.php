<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class AttachmentDocument extends Model
{
    public $incrementing = false;
    protected $keyType = 'string';
    protected $guarded = [];

    protected $casts = [
        'tags' => 'array',
        'current_version' => 'integer',
    ];

    public function employee(): BelongsTo
    {
        return $this->belongsTo(Employee::class);
    }

    public function versions(): HasMany
    {
        return $this->hasMany(AttachmentVersion::class, 'document_id', 'id')->orderBy('version_number', 'asc');
    }

    public function currentVersionRecord()
    {
        return $this->hasOne(AttachmentVersion::class, 'document_id', 'id')->where('is_current', true);
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Employee extends Model
{
    use HasFactory;

    protected $guarded = ['id'];

    protected $casts = [
        'join_date' => 'date',
        'contract_end_date' => 'date',
        'basic_salary' => 'decimal:2',
        'fixed_allowance' => 'decimal:2',
        'daily_attendance_incentive' => 'decimal:2',
        'hourly_overtime_rate' => 'decimal:2',
        'is_active' => 'boolean',
    ];

    public function attendances(): HasMany
    {
        return $this->hasMany(AttendanceDaily::class);
    }

    public function payslips(): HasMany
    {
        return $this->hasMany(Payslip::class);
    }

    public function leaveRequests(): HasMany
    {
        return $this->hasMany(LeaveRequest::class);
    }

    public function gpsLogs(): HasMany
    {
        return $this->hasMany(MobileGpsLog::class);
    }

    public function attachmentDocuments(): HasMany
    {
        return $this->hasMany(AttachmentDocument::class);
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AttendanceDaily extends Model
{
    protected $table = 'attendance_daily';
    protected $guarded = ['id'];

    protected $casts = [
        'attendance_date' => 'date',
        'late_minutes' => 'integer',
        'early_leave_minutes' => 'integer',
        'overtime_hours' => 'decimal:2',
    ];

    public function employee(): BelongsTo
    {
        return $this->belongsTo(Employee::class);
    }

    public function shift(): BelongsTo
    {
        return $this->belongsTo(Shift::class);
    }
}

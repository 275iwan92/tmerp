<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AttachmentVersion extends Model
{
    public $timestamps = false;
    protected $guarded = ['id'];

    protected $casts = [
        'version_number' => 'integer',
        'file_size_kb' => 'integer',
        'ocr_confidence' => 'decimal:2',
        'cost_amount' => 'decimal:2',
        'is_current' => 'boolean',
        'uploaded_at' => 'datetime',
    ];

    public function document(): BelongsTo
    {
        return $this->belongsTo(AttachmentDocument::class, 'document_id', 'id');
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Payslip extends Model
{
    protected $guarded = ['id'];

    protected $casts = [
        'basic_salary' => 'decimal:2',
        'fixed_allowance' => 'decimal:2',
        'overtime_pay' => 'decimal:2',
        'attendance_incentive' => 'decimal:2',
        'gross_salary' => 'decimal:2',
        'late_penalty' => 'decimal:2',
        'alpha_penalty' => 'decimal:2',
        'bpjs_tk_jht_employee' => 'decimal:2',
        'bpjs_tk_jp_employee' => 'decimal:2',
        'bpjs_kes_employee' => 'decimal:2',
        'pph21_ter_amount' => 'decimal:2',
        'total_deductions' => 'decimal:2',
        'net_salary' => 'decimal:2',
        'is_signed_by_employee' => 'boolean',
        'signature_date' => 'datetime',
    ];

    public function employee(): BelongsTo
    {
        return $this->belongsTo(Employee::class);
    }

    public function payrollPeriod(): BelongsTo
    {
        return $this->belongsTo(PayrollPeriod::class);
    }
}

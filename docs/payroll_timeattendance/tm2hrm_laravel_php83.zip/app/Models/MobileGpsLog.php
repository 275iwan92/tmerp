<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class MobileGpsLog extends Model
{
    protected $guarded = ['id'];

    protected $casts = [
        'latitude' => 'decimal:8',
        'longitude' => 'decimal:8',
        'distance_from_office_meters' => 'decimal:2',
        'is_in_radius' => 'boolean',
        'face_biometric_verified' => 'boolean',
        'face_confidence_score' => 'decimal:2',
        'face_liveness_score' => 'decimal:2',
    ];

    public function employee(): BelongsTo
    {
        return $this->belongsTo(Employee::class);
    }
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Shift extends Model
{
    protected $guarded = ['id'];

    protected $casts = [
        'is_cross_day' => 'boolean',
        'late_tolerance_minutes' => 'integer',
    ];

    public function attendances(): HasMany
    {
        return $this->hasMany(AttendanceDaily::class);
    }
}

<?php

namespace App\Filament\Resources;

use App\Filament\Resources\EmployeeResource\Pages;
use App\Models\Employee;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class EmployeeResource extends Resource
{
    protected static ?string $model = Employee::class;
    protected static ?string $navigationIcon = 'heroicon-o-user-group';
    protected static ?string $navigationGroup = 'Master Ketenagakerjaan';
    protected static ?string $modelLabel = 'Karyawan';
    protected static ?string $pluralModelLabel = 'Master Karyawan';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make('Informasi Identitas & Penempatan')
                    ->columns(3)
                    ->schema([
                        Forms\Components\TextInput::make('nik')
                            ->label('NIK (Nomor Induk Karyawan)')
                            ->required()
                            ->unique(ignoreRecord: true),
                        Forms\Components\TextInput::make('full_name')
                            ->label('Nama Lengkap')
                            ->required(),
                        Forms\Components\Select::make('division')
                            ->label('Divisi')
                            ->options([
                                'Divisi Produksi Mesin & Komponen' => 'Divisi Produksi Mesin & Komponen',
                                'Divisi Engineering & Maintenance' => 'Divisi Engineering & Maintenance',
                                'Human Resource & General Affairs' => 'Human Resource & General Affairs',
                                'Finance & Payroll' => 'Finance & Payroll',
                                'Logistik & Gudang Material' => 'Logistik & Gudang Material',
                            ])
                            ->required(),
                        Forms\Components\TextInput::make('position_name')
                            ->label('Jabatan')
                            ->required(),
                        Forms\Components\Select::make('employment_type')
                            ->label('Status Ketenagakerjaan')
                            ->options([
                                'TETAP' => 'Karyawan Tetap (PKWTT)',
                                'KONTRAK_PKWT' => 'Kontrak (PKWT)',
                                'HARIAN_LEPAS' => 'Harian Lepas',
                                'BORONGAN' => 'Borongan Pabrik',
                            ])
                            ->required(),
                        Forms\Components\DatePicker::make('join_date')
                            ->label('Tanggal Masuk')
                            ->required(),
                    ]),

                Forms\Components\Section::make('Struktur Penggajian & Rekening')
                    ->columns(3)
                    ->schema([
                        Forms\Components\TextInput::make('basic_salary')
                            ->label('Gaji Pokok (Rp)')
                            ->numeric()
                            ->prefix('Rp')
                            ->required(),
                        Forms\Components\TextInput::make('fixed_allowance')
                            ->label('Tunjangan Tetap (Rp)')
                            ->numeric()
                            ->prefix('Rp')
                            ->default(0),
                        Forms\Components\TextInput::make('daily_attendance_incentive')
                            ->label('Insentif Kehadiran Harian (Rp)')
                            ->numeric()
                            ->prefix('Rp')
                            ->default(25000),
                        Forms\Components\Select::make('ptkp_status')
                            ->label('Status Pajak (PTKP)')
                            ->options([
                                'TK/0' => 'TK/0 (Lajang)',
                                'TK/1' => 'TK/1 (1 Tanggungan)',
                                'K/0' => 'K/0 (Menikah 0 Anak)',
                                'K/1' => 'K/1 (Menikah 1 Anak)',
                                'K/2' => 'K/2 (Menikah 2 Anak)',
                                'K/3' => 'K/3 (Menikah 3 Anak)',
                            ])
                            ->required(),
                        Forms\Components\Select::make('bank_name')
                            ->label('Nama Bank')
                            ->options([
                                'BCA' => 'Bank Central Asia (BCA)',
                                'MANDIRI' => 'Bank Mandiri',
                                'BRI' => 'Bank Rakyat Indonesia (BRI)',
                                'BNI' => 'Bank Negara Indonesia (BNI)',
                                'CASH' => 'Pembayaran Tunai (Cash)',
                            ])
                            ->required(),
                        Forms\Components\TextInput::make('bank_account_no')
                            ->label('Nomor Rekening'),
                    ]),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('nik')
                    ->label('NIK')
                    ->searchable()
                    ->sortable()
                    ->weight('bold'),
                Tables\Columns\TextColumn::make('full_name')
                    ->label('Nama Karyawan')
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('division')
                    ->label('Divisi')
                    ->badge(),
                Tables\Columns\TextColumn::make('position_name')
                    ->label('Jabatan'),
                Tables\Columns\TextColumn::make('basic_salary')
                    ->label('Gaji Pokok')
                    ->money('IDR', locale: 'id')
                    ->sortable(),
                Tables\Columns\TextColumn::make('bank_name')
                    ->label('Bank')
                    ->badge()
                    ->color('info'),
                Tables\Columns\IconColumn::make('is_active')
                    ->label('Aktif')
                    ->boolean(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('division')
                    ->label('Filter Divisi')
                    ->options([
                        'Divisi Produksi Mesin & Komponen' => 'Produksi',
                        'Divisi Engineering & Maintenance' => 'Engineering',
                        'Human Resource & General Affairs' => 'HR & GA',
                        'Finance & Payroll' => 'Finance',
                        'Logistik & Gudang Material' => 'Logistik',
                    ]),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListEmployees::route('/'),
            'create' => Pages\CreateEmployee::route('/create'),
            'edit' => Pages\EditEmployee::route('/{record}/edit'),
        ];
    }
}

<?php

namespace App\Filament\Resources;

use App\Filament\Resources\AttendanceDailyResource\Pages;
use App\Models\AttendanceDaily;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class AttendanceDailyResource extends Resource
{
    protected static ?string $model = AttendanceDaily::class;
    protected static ?string $navigationIcon = 'heroicon-o-calendar-days';
    protected static ?string $navigationGroup = 'Presensi & Kehadiran';
    protected static ?string $modelLabel = 'Presensi Harian';
    protected static ?string $pluralModelLabel = 'Grid Presensi Harian';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Select::make('employee_id')
                    ->label('Karyawan')
                    ->relationship('employee', 'full_name')
                    ->required(),
                Forms\Components\DatePicker::make('attendance_date')
                    ->label('Tanggal')
                    ->required(),
                Forms\Components\TimePicker::make('clock_in')
                    ->label('Finger In (Masuk)'),
                Forms\Components\TimePicker::make('clock_out')
                    ->label('Finger Out (Pulang)'),
                Forms\Components\Select::make('status_code')
                    ->label('Status Kehadiran')
                    ->options([
                        'H' => 'H (Hadir Tepat Waktu)',
                        'T' => 'T (Terlambat)',
                        'PC' => 'PC (Pulang Cepat)',
                        'S' => 'S (Sakit dengan Surat Dokter)',
                        'I' => 'I (Izin Resmi)',
                        'C' => 'C (Cuti Tahunan FDT)',
                        'A' => 'A (Alpha / Mangkir)',
                        'OFF' => 'OFF (Hari Libur / Shift Off)',
                    ])
                    ->required(),
                Forms\Components\TextInput::make('late_minutes')
                    ->label('Keterlambatan (Menit)')
                    ->numeric()
                    ->default(0),
                Forms\Components\TextInput::make('overtime_hours')
                    ->label('Lembur (Jam)')
                    ->numeric()
                    ->default(0),
                Forms\Components\TextInput::make('notes')
                    ->label('Catatan / Keterangan Form FDT'),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('attendance_date')
                    ->label('Tanggal')
                    ->date('d M Y')
                    ->sortable(),
                Tables\Columns\TextColumn::make('employee.nik')
                    ->label('NIK')
                    ->searchable(),
                Tables\Columns\TextColumn::make('employee.full_name')
                    ->label('Nama Karyawan')
                    ->searchable(),
                Tables\Columns\TextColumn::make('clock_in')
                    ->label('Masuk')
                    ->time('H:i:s'),
                Tables\Columns\TextColumn::make('clock_out')
                    ->label('Pulang')
                    ->time('H:i:s'),
                Tables\Columns\TextColumn::make('status_code')
                    ->label('Status')
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'H' => 'success',
                        'T' => 'warning',
                        'S', 'C' => 'info',
                        'A' => 'danger',
                        default => 'gray',
                    }),
                Tables\Columns\TextColumn::make('late_minutes')
                    ->label('Telat (Mnt)')
                    ->sortable(),
                Tables\Columns\TextColumn::make('overtime_hours')
                    ->label('Lembur (Jam)'),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status_code')
                    ->label('Status')
                    ->options([
                        'H' => 'Hadir',
                        'T' => 'Terlambat',
                        'S' => 'Sakit',
                        'C' => 'Cuti',
                        'A' => 'Alpha',
                    ]),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListAttendanceDailies::route('/'),
        ];
    }
}

<?php

namespace App\Filament\Resources\AttendanceDailyResource\Pages;

use App\Filament\Resources\AttendanceDailyResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListAttendanceDailies extends ListRecords
{
    protected static string $resource = AttendanceDailyResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make()->label('+ Input Presensi Manual'),
        ];
    }
}

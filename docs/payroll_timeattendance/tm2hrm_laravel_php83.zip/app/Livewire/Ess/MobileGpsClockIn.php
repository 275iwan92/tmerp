<?php

namespace App\Livewire\Ess;

use Livewire\Component;
use App\Models\Employee;
use App\Models\MobileGpsLog;
use App\Services\GpsHaversineService;

class MobileGpsClockIn extends Component
{
    public int $employeeId = 1;
    public float $latitude = -7.942205;
    public float $longitude = 112.651060;
    public float $distanceMeters = 0;
    public bool $isInRadius = true;
    public bool $faceVerified = false;
    public float $faceConfidence = 99.4;
    public string $clockType = 'IN';

    public function mount(GpsHaversineService $gpsService)
    {
        $this->updateLocation($gpsService, $this->latitude, $this->longitude);
    }

    public function updateLocation(GpsHaversineService $gpsService, float $lat, float $lng)
    {
        $this->latitude = $lat;
        $this->longitude = $lng;
        $res = $gpsService->calculateDistance($lat, $lng);
        $this->distanceMeters = $res['distance_meters'];
        $this->isInRadius = $res['is_in_radius'];
    }

    public function submitClockIn()
    {
        if (!$this->faceVerified) {
            $this->dispatch('notify', ['type' => 'error', 'message' => 'Lakukan pemindaian wajah biometrik (liveness check) terlebih dahulu.']);
            return;
        }

        MobileGpsLog::create([
            'employee_id' => $this->employeeId,
            'clock_type' => $this->clockType,
            'latitude' => $this->latitude,
            'longitude' => $this->longitude,
            'distance_from_office_meters' => $this->distanceMeters,
            'is_in_radius' => $this->isInRadius,
            'face_biometric_verified' => true,
            'face_confidence_score' => $this->faceConfidence,
            'approval_status' => $this->isInRadius ? 'AUTO_VERIFIED' : 'PENDING_APPROVAL',
        ]);

        $this->dispatch('notify', ['type' => 'success', 'message' => 'Presensi Mobile GPS Berhasil Disimpan!']);
    }

    public function render()
    {
        $employees = Employee::where('is_active', true)->get();
        return view('livewire.ess.mobile-gps-clock-in', compact('employees'));
    }
}

<?php

namespace App\Services;

/**
 * Service Penghitungan PPh 21 Tarif Efektif Rata-Rata (TER)
 * Berdasarkan PP No. 58 Tahun 2023 & PMK No. 168 Tahun 2023
 */
readonly class Pph21TerService
{
    public function getTerCategory(string $ptkpStatus): string
    {
        return match (strtoupper(trim($ptkpStatus))) {
            'TK/0', 'TK/1', 'K/0' => 'A',
            'TK/2', 'TK/3', 'K/1', 'K/2' => 'B',
            'K/3' => 'C',
            default => 'A',
        };
    }

    public function calculateMonthlyTax(float $grossSalary, string $ptkpStatus): array
    {
        $category = $this->getTerCategory($ptkpStatus);
        $rate = match ($category) {
            'A' => $this->getRateCategoryA($grossSalary),
            'B' => $this->getRateCategoryB($grossSalary),
            'C' => $this->getRateCategoryC($grossSalary),
        };

        $taxAmount = round($grossSalary * $rate);

        return [
            'category' => $category,
            'rate' => $rate,
            'rate_percentage' => round($rate * 100, 2),
            'tax_amount' => $taxAmount,
        ];
    }

    private function getRateCategoryA(float $bruto): float
    {
        return match (true) {
            $bruto <= 5400000 => 0.0000,
            $bruto <= 5650000 => 0.0025,
            $bruto <= 5950000 => 0.0050,
            $bruto <= 6300000 => 0.0075,
            $bruto <= 6750000 => 0.0100,
            $bruto <= 7500000 => 0.0125,
            $bruto <= 8550000 => 0.0150,
            $bruto <= 9650000 => 0.0175,
            $bruto <= 10050000 => 0.0200,
            $bruto <= 10350000 => 0.0225,
            $bruto <= 10700000 => 0.0250,
            $bruto <= 11050000 => 0.0300,
            default => 0.0500,
        };
    }

    private function getRateCategoryB(float $bruto): float
    {
        return match (true) {
            $bruto <= 6200000 => 0.0000,
            $bruto <= 6500000 => 0.0025,
            $bruto <= 6850000 => 0.0050,
            $bruto <= 7300000 => 0.0075,
            $bruto <= 9200000 => 0.0100,
            $bruto <= 10750000 => 0.0150,
            default => 0.0300,
        };
    }

    private function getRateCategoryC(float $bruto): float
    {
        return match (true) {
            $bruto <= 6600000 => 0.0000,
            $bruto <= 6950000 => 0.0025,
            $bruto <= 7350000 => 0.0050,
            $bruto <= 7800000 => 0.0075,
            $bruto <= 8850000 => 0.0100,
            $bruto <= 9800000 => 0.0125,
            default => 0.0300,
        };
    }
}

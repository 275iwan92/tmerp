<?php

namespace App\Services;

readonly class GpsHaversineService
{
    // Koordinat Kantor PT. Telasih Makmur (Jl. Raden Panji Suroso No. 12, Blimbing, Malang)
    public const OFFICE_LATITUDE = -7.942205;
    public const OFFICE_LONGITUDE = 112.651060;
    public const MAX_ALLOWED_RADIUS_METERS = 50.0;

    public function calculateDistance(float $latitude, float $longitude): array
    {
        $earthRadius = 6371000; // Meter

        $dLat = deg2rad($latitude - self::OFFICE_LATITUDE);
        $dLon = deg2rad($longitude - self::OFFICE_LONGITUDE);

        $a = sin($dLat / 2) * sin($dLat / 2) +
             cos(deg2rad(self::OFFICE_LATITUDE)) * cos(deg2rad($latitude)) *
             sin($dLon / 2) * sin($dLon / 2);

        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        $distance = round($earthRadius * $c, 1);

        return [
            'distance_meters' => $distance,
            'is_in_radius' => $distance <= self::MAX_ALLOWED_RADIUS_METERS,
            'max_radius_meters' => self::MAX_ALLOWED_RADIUS_METERS,
        ];
    }
}

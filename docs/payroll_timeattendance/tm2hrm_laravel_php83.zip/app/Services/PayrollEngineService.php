<?php

namespace App\Services;

use App\Models\Employee;
use App\Models\AttendanceDaily;

readonly class PayrollEngineService
{
    public function __construct(
        private Pph21TerService $pph21Service,
        private BpjsCalculatorService $bpjsService,
    ) {}

    /**
     * Hitung Gaji Komprehensif Satu Karyawan dalam Periode Tertentu
     */
    public function calculateEmployeePayslip(Employee $employee, string $startDate, string $endDate): array
    {
        // 1. Ambil Rekap Presensi dari Database
        $attendances = AttendanceDaily::where('employee_id', $employee->id)
            ->whereBetween('attendance_date', [$startDate, $endDate])
            ->get();

        $presentDays = $attendances->whereIn('status_code', ['H', 'T', 'PC'])->count();
        $totalLateMinutes = $attendances->sum('late_minutes');
        $alphaDays = $attendances->where('status_code', 'A')->count();
        $totalOvertimeHours = (float) $attendances->sum('overtime_hours');

        // 2. Perhitungan Komponen Pendapatan
        $basicSalary = (float) $employee->basic_salary;
        $fixedAllowance = (float) $employee->fixed_allowance;
        
        // Insentif Kehadiran Harian
        $attendanceIncentive = $presentDays * (float) $employee->daily_attendance_incentive;

        // Upah Lembur Sesuai Depnaker (Kepmenaker No. 102/2004)
        $hourlyRate = (float) $employee->hourly_overtime_rate > 0 
            ? (float) $employee->hourly_overtime_rate 
            : round(($basicSalary + $fixedAllowance) / 173);
            
        $overtimePay = round($totalOvertimeHours * $hourlyRate);

        $grossSalary = $basicSalary + $fixedAllowance + $attendanceIncentive + $overtimePay;

        // 3. Perhitungan Komponen Potongan
        // Denda Keterlambatan: Rp 500 per menit telat
        $latePenalty = $totalLateMinutes * 500;
        
        // Potongan Mangkir (Alpha): Gaji Harian
        $dailyRate = round($basicSalary / 25);
        $alphaPenalty = $alphaDays * $dailyRate;

        // BPJS Karyawan
        $bpjsData = $this->bpjsService->calculate($basicSalary + $fixedAllowance);
        $bpjsTkJht = $bpjsData['employee']['jht'];
        $bpjsTkJp = $bpjsData['employee']['jp'];
        $bpjsKes = $bpjsData['employee']['kes'];

        // Pajak PPh 21 TER
        $pph21Data = $this->pph21Service->calculateMonthlyTax($grossSalary, $employee->ptkp_status);
        $pph21Amount = (float) $pph21Data['tax_amount'];
        $pph21Rate = (float) $pph21Data['rate'];

        $totalDeductions = $latePenalty + $alphaPenalty + $bpjsTkJht + $bpjsTkJp + $bpjsKes + $pph21Amount;
        $netSalary = max(0, $grossSalary - $totalDeductions);

        return [
            'employee_id' => $employee->id,
            'nik' => $employee->nik,
            'full_name' => $employee->full_name,
            'division' => $employee->division,
            'position_name' => $employee->position_name,
            'bank_name' => $employee->bank_name,
            'bank_account_no' => $employee->bank_account_no,
            'basic_salary' => $basicSalary,
            'fixed_allowance' => $fixedAllowance,
            'attendance_days' => $presentDays,
            'attendance_incentive' => $attendanceIncentive,
            'overtime_hours' => $totalOvertimeHours,
            'overtime_pay' => $overtimePay,
            'gross_salary' => $grossSalary,
            'late_minutes' => $totalLateMinutes,
            'late_penalty' => $latePenalty,
            'alpha_days' => $alphaDays,
            'alpha_penalty' => $alphaPenalty,
            'bpjs_tk_jht_employee' => $bpjsTkJht,
            'bpjs_tk_jp_employee' => $bpjsTkJp,
            'bpjs_kes_employee' => $bpjsKes,
            'pph21_ter_rate' => $pph21Rate,
            'pph21_ter_amount' => $pph21Amount,
            'total_deductions' => $totalDeductions,
            'net_salary' => $netSalary,
            'bpjs_tk_company' => $bpjsData['company']['jht'] + $bpjsData['company']['jp'],
            'bpjs_kes_company' => $bpjsData['company']['kes'],
        ];
    }
}

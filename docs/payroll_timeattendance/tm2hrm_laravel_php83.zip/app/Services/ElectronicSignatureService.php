<?php

namespace App\Services;

use App\Models\Payslip;
use Illuminate\Support\Str;

readonly class ElectronicSignatureService
{
    /**
     * Tanda Tangani e-Payslip Karyawan Secara Digital Sesuai UU ITE
     */
    public function signPayslip(
        Payslip $payslip, 
        string $signatureMethod, 
        ?string $canvasDataUrl = null, 
        ?string $ipAddress = null, 
        ?string $deviceInfo = null
    ): Payslip {
        $timestamp = now();
        $payload = sprintf(
            '%s|%s|%s|%s|%s|%s',
            $payslip->nik,
            $payslip->id,
            $payslip->net_salary,
            $timestamp->toIso8601String(),
            $ipAddress ?? '127.0.0.1',
            config('app.key')
        );

        $hash = 'SHA256:' . strtoupper(hash('sha256', $payload));

        $payslip->update([
            'is_signed_by_employee' => true,
            'signature_id' => 'SIG-' . strtoupper(Str::random(10)),
            'signature_method' => $signatureMethod,
            'signature_data_url' => $canvasDataUrl,
            'verification_hash' => $hash,
            'signature_date' => $timestamp,
            'signer_ip_address' => $ipAddress,
            'signer_device_info' => $deviceInfo,
        ]);

        return $payslip->fresh();
    }
}

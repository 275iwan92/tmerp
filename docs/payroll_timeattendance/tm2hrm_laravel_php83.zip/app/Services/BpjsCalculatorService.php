<?php

namespace App\Services;

/**
 * Service Perhitungan Iuran BPJS Ketenagakerjaan & BPJS Kesehatan
 * Sesuai Regulasi Ketenagakerjaan Indonesia
 */
readonly class BpjsCalculatorService
{
    // Plafon Max BPJS Kesehatan & Jaminan Pensiun (Tahun 2026)
    public const BPJS_KES_MAX_CAP = 12000000.00;
    public const BPJS_JP_MAX_CAP = 10547400.00;

    public function calculate(float $baseSalary): array
    {
        $baseKes = min($baseSalary, self::BPJS_KES_MAX_CAP);
        $baseJp = min($baseSalary, self::BPJS_JP_MAX_CAP);

        // BPJS Ketenagakerjaan
        // JHT: Karyawan 2%, Perusahaan 3.7%
        $jhtEmployee = round($baseSalary * 0.02);
        $jhtCompany = round($baseSalary * 0.037);

        // JP (Jaminan Pensiun): Karyawan 1%, Perusahaan 2%
        $jpEmployee = round($baseJp * 0.01);
        $jpCompany = round($baseJp * 0.02);

        // JKK (0.24% - 1.74%) & JKM (0.3%) dibayar penuh oleh Perusahaan
        $jkkCompany = round($baseSalary * 0.0024);
        $jkmCompany = round($baseSalary * 0.0030);

        // BPJS Kesehatan: Karyawan 1%, Perusahaan 4%
        $kesEmployee = round($baseKes * 0.01);
        $kesCompany = round($baseKes * 0.04);

        $totalEmployeeDeduction = $jhtEmployee + $jpEmployee + $kesEmployee;
        $totalCompanyContribution = $jhtCompany + $jpCompany + $jkkCompany + $jkmCompany + $kesCompany;

        return [
            'employee' => [
                'jht' => $jhtEmployee,
                'jp' => $jpEmployee,
                'kes' => $kesEmployee,
                'total' => $totalEmployeeDeduction,
            ],
            'company' => [
                'jht' => $jhtCompany,
                'jp' => $jpCompany,
                'jkk' => $jkkCompany,
                'jkm' => $jkmCompany,
                'kes' => $kesCompany,
                'total' => $totalCompanyContribution,
            ],
            'grand_total' => $totalEmployeeDeduction + $totalCompanyContribution,
        ];
    }
}

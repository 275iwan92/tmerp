<?php

use Illuminate\Support\Facades\Route;
use App\Livewire\Ess\MobileGpsClockIn;

Route::get('/', function () {
    return redirect('/admin');
});

Route::get('/ess/clock-in', MobileGpsClockIn::class)->name('ess.clock-in');

Route::get('/health', function () {
    return response()->json([
        'status' => 'ok',
        'system' => 'TM2HRM ERP PT Telasih Makmur',
        'php_version' => PHP_VERSION,
        'framework' => 'Laravel v12/v13 + Filament v3/v4 + Livewire v3/v4',
        'timestamp' => now()->toIso8601String(),
    ]);
});

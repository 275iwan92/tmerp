<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Models\FingerRawLog;
use App\Models\Employee;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

// Webhook / API Endpoint Mesin Fingerprint (Solution / ZKTeco)
Route::post('/fingerprint/push-log', function (Request $request) {
    $validated = $request->validate([
        'device_pin' => 'required|string',
        'nik' => 'required|string',
        'timestamp' => 'required|date',
    ]);

    $log = FingerRawLog::create([
        'device_pin' => $validated['device_pin'],
        'nik' => $validated['nik'],
        'log_timestamp' => $validated['timestamp'],
        'verify_type' => $request->input('verify_type', 'FINGER'),
    ]);

    return response()->json(['status' => 'success', 'log_id' => $log->id]);
});

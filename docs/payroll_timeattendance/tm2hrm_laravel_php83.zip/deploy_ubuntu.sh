#!/bin/bash
# ============================================================================
# SKRIP INSTALASI OTOMATIS LARAVEL + FILAMENT DI UBUNTU SERVER 22.04 LTS
# PT. TELASIH MAKMUR (BLIMBING, MALANG)
# ============================================================================

set -e

echo "🚀 Memulai Setup Laravel 11/12/13 + PHP 8.3 + Filament + Livewire..."

# 1. Pastikan PHP 8.3 terinstall
if ! command -v php8.3 &> /dev/null
then
    echo "📦 Menambahkan PPA Ondrej PHP & Menginstall PHP 8.3..."
    sudo apt update
    sudo apt install -y software-properties-common
    sudo add-apt-repository -y ppa:ondrej/php
    sudo apt update
    sudo apt install -y php8.3 php8.3-cli php8.3-fpm php8.3-mysql php8.3-mbstring \
        php8.3-xml php8.3-bcmath php8.3-curl php8.3-gd php8.3-zip php8.3-intl unzip curl git
fi

# 2. Pastikan Composer terinstall
if ! command -v composer &> /dev/null
then
    echo "📦 Menginstall Composer..."
    curl -sS https://getcomposer.org/installer | php
    sudo mv composer.phar /usr/local/bin/composer
fi

# 3. Setup .env file
if [ ! -f .env ]; then
    cp .env.example .env
    echo "✔ File .env disiapkan."
fi

# 4. Install PHP Dependencies
echo "📦 Menjalankan composer install..."
composer install --no-interaction --prefer-dist --optimize-autoloader

# 5. Generate Application Key
php artisan key:generate

# 6. Jalankan Migrasi & Database Seeder
echo "🗄 Menjalankan Database Migrations & Initial Seeders..."
php artisan migrate:fresh --seed --force

# 7. Symlink Storage
php artisan storage:link || true

# 8. Set Permissions Direktori Storage
sudo chmod -R 775 storage bootstrap/cache
sudo chown -R www-data:www-data storage bootstrap/cache || true

echo "🎉 INSTALASI SELESAI!"
echo "👉 Jalankan 'php artisan serve --port=8000' untuk menjalankan aplikasi secara lokal."
echo "👉 Buka Browser: http://localhost:8000/admin untuk login ke Filament Panel HRIS."

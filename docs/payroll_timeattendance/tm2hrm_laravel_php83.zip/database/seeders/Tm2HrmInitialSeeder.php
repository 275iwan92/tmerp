<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class Tm2HrmInitialSeeder extends Seeder
{
    public function run(): void
    {
        // 1. Shifts
        DB::table('shifts')->insert([
            ['id' => 1, 'shift_code' => 'SHIFT-1', 'name' => 'Shift Pagi Reguler', 'start_time' => '07:30:00', 'end_time' => '16:30:00', 'late_tolerance_minutes' => 15, 'is_cross_day' => false],
            ['id' => 2, 'shift_code' => 'SHIFT-2', 'name' => 'Shift Siang Produksi', 'start_time' => '15:30:00', 'end_time' => '23:30:00', 'late_tolerance_minutes' => 15, 'is_cross_day' => false],
            ['id' => 3, 'shift_code' => 'SHIFT-3', 'name' => 'Shift Malam Pabrik (H+1)', 'start_time' => '23:30:00', 'end_time' => '07:30:00', 'late_tolerance_minutes' => 15, 'is_cross_day' => true],
        ]);

        // 2. Employees PT Telasih Makmur
        DB::table('employees')->insert([
            [
                'id' => 1,
                'nik' => 'TM-2024-001',
                'full_name' => 'Ahmad Pratama',
                'division' => 'Divisi Produksi Mesin & Komponen',
                'position_name' => 'Senior Operator Mesin Bubut CNC',
                'employment_type' => 'TETAP',
                'join_date' => '2022-03-01',
                'ptkp_status' => 'K/1',
                'basic_salary' => 4500000.00,
                'fixed_allowance' => 500000.00,
                'daily_attendance_incentive' => 25000.00,
                'hourly_overtime_rate' => 28901.00,
                'bank_name' => 'BCA',
                'bank_account_no' => '1420988771',
                'bank_account_holder' => 'Ahmad Pratama',
                'is_active' => true,
            ],
            [
                'id' => 2,
                'nik' => 'TM-2024-002',
                'full_name' => 'Budi Santoso',
                'division' => 'Divisi Produksi Mesin & Komponen',
                'position_name' => 'Operator Mesin Milling',
                'employment_type' => 'KONTRAK_PKWT',
                'join_date' => '2023-01-15',
                'ptkp_status' => 'TK/0',
                'basic_salary' => 4200000.00,
                'fixed_allowance' => 350000.00,
                'daily_attendance_incentive' => 25000.00,
                'hourly_overtime_rate' => 26300.00,
                'bank_name' => 'MANDIRI',
                'bank_account_no' => '1370019283741',
                'bank_account_holder' => 'Budi Santoso',
                'is_active' => true,
            ],
            [
                'id' => 3,
                'nik' => 'TM-2024-003',
                'full_name' => 'Citra Dewi',
                'division' => 'Human Resource & General Affairs',
                'position_name' => 'HR Officer & Payroll Staff',
                'employment_type' => 'TETAP',
                'join_date' => '2021-08-10',
                'ptkp_status' => 'TK/0',
                'basic_salary' => 4800000.00,
                'fixed_allowance' => 600000.00,
                'daily_attendance_incentive' => 30000.00,
                'hourly_overtime_rate' => 31213.00,
                'bank_name' => 'BCA',
                'bank_account_no' => '1420766542',
                'bank_account_holder' => 'Citra Dewi',
                'is_active' => true,
            ],
        ]);

        // 3. Attachment Documents
        DB::table('attachment_documents')->insert([
            [
                'id' => 'DOC-2026-001',
                'related_form_no' => 'FDT-2026-08-012',
                'employee_id' => 1,
                'employee_name' => 'Ahmad Pratama',
                'nik' => 'TM-2024-001',
                'division' => 'Divisi Produksi Mesin & Komponen',
                'category' => 'DOCTOR_LETTER',
                'title' => 'Surat Sakit & Kwitansi Rawat Inap RS Lavalette Malang',
                'current_version' => 2,
                'tags' => json_encode(['surat-dokter', 'rawat-inap']),
                'status' => 'VERIFIED',
                'extracted_summary' => 'Diagnosis Gejala Tipes Ringan. Istirahat 3 hari.',
            ],
        ]);

        DB::table('attachment_versions')->insert([
            [
                'document_id' => 'DOC-2026-001',
                'version_id' => 'DOC-2026-001-v1',
                'version_number' => 1,
                'file_name' => 'Surat_Dokter_Ahmad_Pratama.pdf',
                'file_size_kb' => 540,
                'file_type' => 'PDF',
                'uploaded_by' => 'Ahmad Pratama (ESS)',
                'change_notes' => 'Unggahan awal surat istirahat dokter.',
                'extracted_text' => 'SURAT KETERANGAN DOKTER RS LAVALETTE MALANG. Pasien: Ahmad Pratama.',
                'ocr_confidence' => 98.20,
                'cost_amount' => 450000.00,
                'is_current' => false,
            ],
            [
                'document_id' => 'DOC-2026-001',
                'version_id' => 'DOC-2026-001-v2',
                'version_number' => 2,
                'file_name' => 'Surat_Dokter_Ahmad_Pratama_Revisi_Kwitansi.pdf',
                'file_size_kb' => 820,
                'file_type' => 'PDF',
                'uploaded_by' => 'HR Admin',
                'change_notes' => 'Revisi penambahan kwitansi obat resmi apotek.',
                'extracted_text' => 'LAMPIRAN LENGKAP RS LAVALETTE & KWITANSI APOTEK. Pasien: Ahmad Pratama. Total: Rp 750.000.',
                'ocr_confidence' => 99.10,
                'cost_amount' => 750000.00,
                'is_current' => true,
            ],
        ]);
    }
}

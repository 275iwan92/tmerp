<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // 1. Divisi
        Schema::create('divisions', function (Blueprint $table) {
            $table->id();
            $table->string('code', 20)->unique();
            $table->string('name', 100);
            $table->timestamps();
        });

        // 2. Shift Kerja
        Schema::create('shifts', function (Blueprint $table) {
            $table->id();
            $table->string('shift_code', 20)->unique();
            $table->string('name', 100);
            $table->time('start_time');
            $table->time('end_time');
            $table->integer('late_tolerance_minutes')->default(15);
            $table->boolean('is_cross_day')->default(false);
            $table->timestamps();
        });

        // 3. Karyawan (Employees)
        Schema::create('employees', function (Blueprint $table) {
            $table->id();
            $table->string('nik', 20)->unique();
            $table->string('full_name', 150);
            $table->string('division', 100);
            $table->string('position_name', 100);
            $table->enum('employment_type', ['TETAP', 'KONTRAK_PKWT', 'HARIAN_LEPAS', 'BORONGAN'])->default('KONTRAK_PKWT');
            $table->date('join_date');
            $table->date('contract_end_date')->nullable();
            $table->string('ptkp_status', 10)->default('TK/0');
            $table->decimal('basic_salary', 15, 2)->default(0);
            $table->decimal('fixed_allowance', 15, 2)->default(0);
            $table->decimal('daily_attendance_incentive', 15, 2)->default(0);
            $table->decimal('hourly_overtime_rate', 15, 2)->default(0);
            $table->string('bank_name', 50)->default('BCA');
            $table->string('bank_account_no', 50)->default('');
            $table->string('bank_account_holder', 150)->default('');
            $table->string('bpjs_tk_no', 50)->nullable();
            $table->string('bpjs_kes_no', 50)->nullable();
            $table->string('npwp_no', 50)->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // 4. Raw Logs Fingerprint
        Schema::create('finger_raw_logs', function (Blueprint $table) {
            $table->id();
            $table->string('machine_id', 50)->default('MESIN_FINGER_PANJI_01');
            $table->string('device_pin', 30);
            $table->string('nik', 20);
            $table->dateTime('log_timestamp');
            $table->string('verify_type', 20)->default('FINGER');
            $table->string('source_file', 100)->nullable();
            $table->timestamps();
            $table->index(['nik', 'log_timestamp']);
        });

        // 5. Mobile GPS & Face Biometric Log (ESS)
        Schema::create('mobile_gps_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('employee_id')->constrained()->cascadeOnDelete();
            $table->enum('clock_type', ['IN', 'OUT']);
            $table->decimal('latitude', 10, 8);
            $table->decimal('longitude', 11, 8);
            $table->decimal('distance_from_office_meters', 8, 2);
            $table->boolean('is_in_radius')->default(false);
            $table->decimal('gps_accuracy', 5, 2)->default(5.00);
            $table->boolean('face_biometric_verified')->default(true);
            $table->decimal('face_confidence_score', 5, 2)->default(99.40);
            $table->decimal('face_liveness_score', 5, 2)->default(98.70);
            $table->integer('face_landmarks_detected')->default(68);
            $table->string('photo_selfie_path', 255)->nullable();
            $table->enum('approval_status', ['AUTO_VERIFIED', 'PENDING_APPROVAL', 'APPROVED', 'REJECTED'])->default('AUTO_VERIFIED');
            $table->text('hr_approval_note')->nullable();
            $table->timestamps();
            $table->index(['employee_id', 'created_at']);
        });

        // 6. Daily Attendance Grid
        Schema::create('attendance_daily', function (Blueprint $table) {
            $table->id();
            $table->foreignId('employee_id')->constrained()->cascadeOnDelete();
            $table->date('attendance_date');
            $table->foreignId('shift_id')->nullable()->constrained()->nullOnDelete();
            $table->time('clock_in')->nullable();
            $table->time('clock_out')->nullable();
            $table->enum('status_code', ['H', 'T', 'PC', 'I', 'S', 'C', 'A', 'OFF'])->default('A');
            $table->integer('late_minutes')->default(0);
            $table->integer('early_leave_minutes')->default(0);
            $table->decimal('overtime_hours', 4, 2)->default(0.00);
            $table->string('fdt_leave_form_no', 50)->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->unique(['employee_id', 'attendance_date']);
        });

        // 7. Pengajuan Cuti / Izin FDT
        Schema::create('leave_requests', function (Blueprint $table) {
            $table->id();
            $table->string('form_no', 50)->unique();
            $table->foreignId('employee_id')->constrained()->cascadeOnDelete();
            $table->enum('leave_type', ['ANNUAL_LEAVE', 'SICK_LEAVE', 'SPECIAL_PERMISSION', 'MATERNITY', 'UNPAID_LEAVE']);
            $table->date('start_date');
            $table->date('end_date');
            $table->integer('total_days')->default(1);
            $table->text('reason');
            $table->string('attachment_doc_path', 255)->nullable();
            $table->enum('hr_approval_status', ['PENDING', 'APPROVED', 'REJECTED'])->default('PENDING');
            $table->string('approver_name', 100)->nullable();
            $table->dateTime('approval_date')->nullable();
            $table->text('rejection_reason')->nullable();
            $table->timestamps();
        });

        // 8. Periode Payroll
        Schema::create('payroll_periods', function (Blueprint $table) {
            $table->id();
            $table->string('period_name', 100);
            $table->date('start_date');
            $table->date('end_date');
            $table->date('pay_date');
            $table->enum('period_type', ['WEEKLY', 'MONTHLY'])->default('WEEKLY');
            $table->enum('status', ['DRAFT', 'CALCULATED', 'LOCKED', 'PAID'])->default('DRAFT');
            $table->decimal('total_disbursement', 15, 2)->default(0.00);
            $table->timestamps();
        });

        // 9. Payslips & E-Signature
        Schema::create('payslips', function (Blueprint $table) {
            $table->id();
            $table->foreignId('payroll_period_id')->constrained()->cascadeOnDelete();
            $table->foreignId('employee_id')->constrained()->cascadeOnDelete();
            $table->string('nik', 20);
            $table->string('full_name', 150);
            $table->string('division', 100);
            $table->string('position_name', 100);
            $table->enum('payment_method', ['BANK_TRANSFER', 'CASH'])->default('BANK_TRANSFER');
            $table->string('bank_name', 50)->default('BCA');
            $table->string('bank_account_no', 50)->default('');

            // Pendapatan
            $table->decimal('basic_salary', 15, 2)->default(0);
            $table->decimal('fixed_allowance', 15, 2)->default(0);
            $table->decimal('overtime_hours', 5, 2)->default(0);
            $table->decimal('overtime_pay', 15, 2)->default(0);
            $table->integer('attendance_days')->default(0);
            $table->decimal('attendance_incentive', 15, 2)->default(0);
            $table->decimal('gross_salary', 15, 2)->default(0);

            // Potongan
            $table->integer('late_minutes')->default(0);
            $table->decimal('late_penalty', 15, 2)->default(0);
            $table->integer('alpha_days')->default(0);
            $table->decimal('alpha_penalty', 15, 2)->default(0);
            $table->decimal('bpjs_tk_jht_employee', 15, 2)->default(0);
            $table->decimal('bpjs_tk_jp_employee', 15, 2)->default(0);
            $table->decimal('bpjs_kes_employee', 15, 2)->default(0);
            $table->decimal('pph21_ter_rate', 5, 4)->default(0);
            $table->decimal('pph21_ter_amount', 15, 2)->default(0);
            $table->decimal('total_deductions', 15, 2)->default(0);
            $table->decimal('net_salary', 15, 2)->default(0);

            // Kontribusi Perusahaan
            $table->decimal('bpjs_tk_company', 15, 2)->default(0);
            $table->decimal('bpjs_kes_company', 15, 2)->default(0);

            // Tanda Tangan Elektronik
            $table->boolean('is_signed_by_employee')->default(false);
            $table->string('signature_id', 50)->nullable();
            $table->enum('signature_method', ['DRAWN_CANVAS', 'CRYPTOGRAPHIC_TOKEN'])->nullable();
            $table->mediumText('signature_data_url')->nullable();
            $table->string('verification_hash', 100)->nullable();
            $table->dateTime('signature_date')->nullable();
            $table->string('signer_ip_address', 50)->nullable();
            $table->string('signer_device_info', 150)->nullable();

            $table->timestamps();
        });

        // 10. Pusat Arsip Lampiran (Attachment Documents)
        Schema::create('attachment_documents', function (Blueprint $table) {
            $table->string('id', 50)->primary(); // DOC-2026-001
            $table->string('related_form_no', 50)->nullable();
            $table->foreignId('employee_id')->constrained()->cascadeOnDelete();
            $table->string('employee_name', 150);
            $table->string('nik', 20);
            $table->string('division', 100);
            $table->enum('category', ['DOCTOR_LETTER', 'RECEIPT', 'LEAVE_FORM', 'EMPLOYMENT_CONTRACT', 'IDENTITY_CARD', 'OTHER']);
            $table->string('title', 200);
            $table->unsignedInteger('current_version')->default(1);
            $table->json('tags')->nullable();
            $table->enum('status', ['VERIFIED', 'PENDING_REVIEW', 'REJECTED'])->default('VERIFIED');
            $table->text('extracted_summary')->nullable();
            $table->timestamps();
        });

        // 11. Version Control Lampiran (Attachment Versions)
        Schema::create('attachment_versions', function (Blueprint $table) {
            $table->id();
            $table->string('document_id', 50);
            $table->string('version_id', 60)->unique();
            $table->unsignedInteger('version_number');
            $table->string('file_name', 255);
            $table->unsignedInteger('file_size_kb')->default(0);
            $table->enum('file_type', ['PDF', 'IMAGE_JPG', 'IMAGE_PNG', 'DOCX', 'XLSX'])->default('PDF');
            $table->string('uploaded_by', 100);
            $table->text('change_notes')->nullable();
            $table->longText('extracted_text')->nullable();
            $table->decimal('ocr_confidence', 5, 2)->default(98.50);
            $table->string('doctor_name', 150)->nullable();
            $table->string('clinic_hospital', 150)->nullable();
            $table->string('diagnosis', 200)->nullable();
            $table->decimal('cost_amount', 15, 2)->nullable();
            $table->boolean('is_current')->default(false);
            $table->timestamp('uploaded_at')->useCurrent();

            $table->foreign('document_id')->references('id')->on('attachment_documents')->cascadeOnDelete();
            $table->index(['document_id', 'version_number']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('attachment_versions');
        Schema::dropIfExists('attachment_documents');
        Schema::dropIfExists('payslips');
        Schema::dropIfExists('payroll_periods');
        Schema::dropIfExists('leave_requests');
        Schema::dropIfExists('attendance_daily');
        Schema::dropIfExists('mobile_gps_logs');
        Schema::dropIfExists('finger_raw_logs');
        Schema::dropIfExists('employees');
        Schema::dropIfExists('shifts');
        Schema::dropIfExists('divisions');
    }
};

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SysChatMessage extends Model
{
    protected $table = 'sys_chat_messages';
    public $timestamps = false;
    
    protected $fillable = ['conversation_id', 'sender', 'body', 'sent_at'];
    protected $casts = [
        'sent_at' => 'datetime',
    ];

    public function conversation(): BelongsTo
    {
        return $this->belongsTo(SysChatConversation::class, 'conversation_id', 'id');
    }

    public function senderUser(): BelongsTo
    {
        return $this->belongsTo(SecUser::class, 'sender', 'login');
    }
}

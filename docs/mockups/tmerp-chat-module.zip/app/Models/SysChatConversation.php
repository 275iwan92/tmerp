<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class SysChatConversation extends Model
{
    protected $table = 'sys_chat_conversations';
    public $timestamps = false;
    
    protected $fillable = ['is_group', 'title', 'created_at'];
    protected $casts = [
        'is_group' => 'boolean',
        'created_at' => 'datetime',
    ];

    public function participants(): HasMany
    {
        return $this->hasMany(SysChatParticipant::class, 'conversation_id', 'id');
    }

    public function messages(): HasMany
    {
        return $this->hasMany(SysChatMessage::class, 'conversation_id', 'id');
    }

    public function lastMessage(): HasOne
    {
        return $this->hasOne(SysChatMessage::class, 'conversation_id', 'id')->latest('sent_at');
    }
}

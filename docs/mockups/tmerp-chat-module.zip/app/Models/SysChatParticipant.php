<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SysChatParticipant extends Model
{
    protected $table = 'sys_chat_participants';
    public $timestamps = false;
    
    protected $fillable = ['conversation_id', 'user_id', 'last_read_at'];
    protected $casts = [
        'last_read_at' => 'datetime',
    ];

    public function conversation(): BelongsTo
    {
        return $this->belongsTo(SysChatConversation::class, 'conversation_id', 'id');
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(SecUser::class, 'user_id', 'login');
    }
}

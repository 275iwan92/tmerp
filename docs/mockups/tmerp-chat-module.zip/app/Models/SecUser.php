<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class SecUser extends Authenticatable
{
    protected $table = 'sec_user';
    protected $primaryKey = 'id_user';

    public function chatConversations(): BelongsToMany
    {
        return $this->belongsToMany(
            SysChatConversation::class,
            'sys_chat_participants',
            'user_id',
            'conversation_id',
            'login', // Local key on sec_user
            'id'     // Local key on sys_chat_conversations
        )->withPivot('last_read_at');
    }
}

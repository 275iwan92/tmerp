<?php
namespace App\Livewire\Chat;
use Livewire\Component;
use Livewire\Attributes\On;
use Illuminate\Support\Facades\DB;

class ChatBadge extends Component
{
    public $count = 0;

    public function mount() { $this->calculateUnread(); }

    #[On('unread-count-updated')]
    public function calculateUnread()
    {
        $login = auth()->user()->login;
        $this->count = DB::table('sys_chat_messages as m')
            ->join('sys_chat_participants as p', 'm.conversation_id', '=', 'p.conversation_id')
            ->where('p.user_id', $login)
            ->whereRaw('m.sent_at > IFNULL(p.last_read_at, "2000-01-01")')
            ->count();
    }

    public function render()
    {
        return view('livewire.chat.chat-badge');
    }
}

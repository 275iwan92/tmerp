<?php

namespace App\Livewire\Chat;

use Livewire\Component;
use Livewire\Attributes\On;
use Livewire\Attributes\Computed;
use App\Models\SecUser;
use App\Models\SysChatConversation;
use App\Models\SysChatParticipant;
use App\Models\SysChatMessage;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ChatDrawer extends Component
{
    public $mode = 'list'; // 'list' | 'room'
    public $activeConversationId = null;
    public $searchQuery = '';
    public $messageBody = '';
    
    public $userSearchQuery = '';
    public $showNewChatModal = false;

    #[On('chatOpen')]
    public function openDrawer()
    {
        $this->dispatch('toggle-chat-drawer');
    }

    #[Computed]
    public function conversations()
    {
        $login = Auth::user()->login;

        return SysChatConversation::whereHas('participants', function ($query) use ($login) {
                $query->where('user_id', $login);
            })
            ->with(['participants.user', 'lastMessage'])
            ->get()
            ->filter(function ($conv) {
                if (!empty($this->searchQuery)) {
                    $name = $this->getConversationName($conv);
                    return stripos(strtolower($name), strtolower($this->searchQuery)) !== false;
                }
                return true;
            })
            ->sortByDesc(function ($conv) {
                return $conv->lastMessage ? $conv->lastMessage->sent_at : $conv->created_at;
            });
    }

    #[Computed]
    public function activeConversation()
    {
        if (!$this->activeConversationId) return null;
        
        return SysChatConversation::with(['messages' => function($q) {
            $q->orderBy('sent_at', 'asc');
        }, 'participants.user'])->find($this->activeConversationId);
    }

    #[Computed]
    public function availableUsers()
    {
        if (empty(trim($this->userSearchQuery))) return [];

        return SecUser::where('activate', 1)
            ->where('login', '!=', Auth::user()->login)
            ->where(function($q) {
                $q->where('name', 'like', '%' . $this->userSearchQuery . '%')
                  ->orWhere('login', 'like', '%' . $this->userSearchQuery . '%');
            })
            ->limit(10)
            ->get();
    }

    public function selectConversation($id)
    {
        $this->activeConversationId = $id;
        $this->mode = 'room';
        $this->markAsRead($id);
        $this->dispatch('scroll-bottom');
    }

    public function markAsRead($conversationId)
    {
        SysChatParticipant::where('conversation_id', $conversationId)
            ->where('user_id', Auth::user()->login)
            ->update(['last_read_at' => now()]);
            
        $this->dispatch('unread-count-updated');
    }

    public function backToList()
    {
        $this->mode = 'list';
        $this->activeConversationId = null;
        $this->dispatch('unread-count-updated');
    }

    public function sendMessage()
    {
        if (empty(trim($this->messageBody)) || !$this->activeConversationId) {
            return;
        }

        SysChatMessage::create([
            'conversation_id' => $this->activeConversationId,
            'sender' => Auth::user()->login,
            'body' => trim($this->messageBody),
            'sent_at' => now(),
        ]);

        $this->messageBody = '';
        $this->markAsRead($this->activeConversationId);
        $this->dispatch('scroll-bottom');
    }

    public function startDirectChat($targetLogin)
    {
        $login = Auth::user()->login;

        // Validasi apakah thread 1-on-1 sudah ada
        $existingConv = SysChatConversation::where('is_group', 0)
            ->whereHas('participants', fn($q) => $q->where('user_id', $login))
            ->whereHas('participants', fn($q) => $q->where('user_id', $targetLogin))
            ->first();

        if ($existingConv) {
            $this->selectConversation($existingConv->id);
        } else {
            DB::transaction(function() use ($login, $targetLogin, &$conv) {
                $conv = SysChatConversation::create([
                    'is_group' => 0,
                    'created_at' => now(),
                ]);

                SysChatParticipant::insert([
                    ['conversation_id' => $conv->id, 'user_id' => $login, 'last_read_at' => now()],
                    ['conversation_id' => $conv->id, 'user_id' => $targetLogin, 'last_read_at' => null],
                ]);
            });

            $this->selectConversation($conv->id);
        }

        $this->showNewChatModal = false;
        $this->userSearchQuery = '';
    }

    public function getConversationName($conversation)
    {
        if ($conversation->is_group) return $conversation->title;

        $otherParticipant = $conversation->participants->firstWhere('user_id', '!=', Auth::user()->login);
        return $otherParticipant ? $otherParticipant->user->name : 'Unknown User';
    }

    public function getUnreadCountForConv($conversation)
    {
        $login = Auth::user()->login;
        $participant = $conversation->participants->firstWhere('user_id', $login);
        $lastRead = $participant ? $participant->last_read_at : null;

        if (!$lastRead) return $conversation->messages->count();

        return $conversation->messages->where('sent_at', '>', $lastRead)->count();
    }

    public function render()
    {
        return view('livewire.chat.chat-drawer');
    }
}

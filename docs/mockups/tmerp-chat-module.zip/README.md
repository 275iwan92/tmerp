# TMERP Slide-over Chat Module

This module provides the Laravel 13, Livewire v4, and Alpine.js implementation for the slide-over chat drawer.

## Installation Instructions

1. Copy the `app/` and `resources/` directories into your TMERP Laravel project root.
2. Make sure you have `livewire/livewire` (v3 or v4) installed.
3. Run `php artisan view:clear` if necessary.

## Integration

Add the `<livewire:chat.chat-drawer />` component to the bottom of your main layout file (`resources/views/layouts/app.blade.php`), preferably just above the closing `</body>` tag:

```blade
<!-- Modul Internal Chat -->
<livewire:chat.chat-drawer />
```

To trigger the chat drawer from a button, dispatch the `chatOpen` Alpine/Livewire event:
```blade
<button @click="$dispatch('chatOpen')">Open Chat</button>
```

To show the real-time unread badge (e.g. on your Topbar Menu or Avatar), include the badge component inside your button:
```blade
<button @click="$dispatch('chatOpen')" class="relative p-2">
    <i class="fa-solid fa-comment-dots"></i>
    <livewire:chat.chat-badge />
</button>
```

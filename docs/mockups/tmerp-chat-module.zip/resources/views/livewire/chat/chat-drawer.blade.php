<div 
    x-data="{ 
        chatOpen: false, 
        scrollToBottom() { 
            $nextTick(() => {
                let el = $refs.chatBody;
                if(el) el.scrollTop = el.scrollHeight;
            });
        }
    }"
    x-on:toggle-chat-drawer.window="chatOpen = !chatOpen"
    x-on:scroll-bottom.window="scrollToBottom()"
    class="relative z-50"
    role="dialog" 
    aria-modal="true"
>
    <!-- Background Overlay -->
    <div 
        x-show="chatOpen" 
        x-transition:enter="ease-in-out duration-300" 
        x-transition:enter-start="opacity-0" 
        x-transition:enter-end="opacity-100" 
        x-transition:leave="ease-in-out duration-300" 
        x-transition:leave-start="opacity-100" 
        x-transition:leave-end="opacity-0" 
        class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity"
        @click="chatOpen = false"
        style="display: none;"
    ></div>

    <div class="fixed inset-0 overflow-hidden pointer-events-none">
        <div class="absolute inset-0 overflow-hidden">
            <div class="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10">
                
                <!-- Drawer Panel -->
                <div 
                    x-show="chatOpen" 
                    x-transition:enter="transform transition ease-in-out duration-300" 
                    x-transition:enter-start="translate-x-full" 
                    x-transition:enter-end="translate-x-0" 
                    x-transition:leave="transform transition ease-in-out duration-300" 
                    x-transition:leave-start="translate-x-0" 
                    x-transition:leave-end="translate-x-full" 
                    class="pointer-events-auto w-screen max-w-[400px]"
                    style="display: none;"
                >
                    <div class="flex h-full flex-col bg-[#101b30] shadow-2xl border-l border-slate-700">
                        
                        <!-- MODE 1: LIST CONVERSATION -->
                        @if($mode === 'list')
                            <div class="px-4 py-4 bg-[#1f2742] shadow border-b border-slate-700 z-10 flex items-center justify-between">
                                <div class="flex items-center gap-3">
                                    <div class="w-8 h-8 rounded bg-blue-600 flex items-center justify-center text-white">
                                        <i class="fa-solid fa-comments"></i>
                                    </div>
                                    <h2 class="text-base font-semibold text-white">Pesan Internal</h2>
                                </div>
                                <div class="flex items-center gap-3">
                                    <button wire:click="$set('showNewChatModal', true)" class="w-8 h-8 rounded-full bg-slate-700 hover:bg-slate-600 text-slate-300 hover:text-white flex items-center justify-center transition-colors">
                                        <i class="fa-solid fa-plus"></i>
                                    </button>
                                    <button @click="chatOpen = false" class="text-slate-400 hover:text-white transition-colors">
                                        <i class="fa-solid fa-xmark text-xl"></i>
                                    </button>
                                </div>
                            </div>
                            
                            <div class="p-3 bg-[#101b30] border-b border-slate-700">
                                <div class="relative">
                                    <input wire:model.live.debounce.300ms="searchQuery" type="text" class="w-full bg-[#1f2742] text-white border border-slate-600 rounded-lg py-2 pl-9 pr-3 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 placeholder-slate-400" placeholder="Cari obrolan...">
                                    <i class="fa-solid fa-magnifying-glass absolute left-3 top-2.5 text-slate-400"></i>
                                </div>
                            </div>

                            <div class="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-700">
                                <ul class="divide-y divide-slate-800" wire:poll.5s>
                                    @forelse($this->conversations as $conv)
                                        @php
                                            $unread = $this->getUnreadCountForConv($conv);
                                            $name = $this->getConversationName($conv);
                                        @endphp
                                        <li wire:click="selectConversation({{ $conv->id }})" class="p-4 hover:bg-[#1f2742] cursor-pointer transition-colors group">
                                            <div class="flex items-center gap-3">
                                                <div class="relative flex-shrink-0">
                                                    <div class="w-11 h-11 rounded-full bg-gradient-to-br from-slate-600 to-slate-800 flex items-center justify-center text-white font-medium border border-slate-600">
                                                        {{ strtoupper(substr($name, 0, 1)) }}
                                                    </div>
                                                    @if($conv->is_group)
                                                        <div class="absolute -bottom-1 -right-1 w-5 h-5 bg-[#101b30] rounded-full flex items-center justify-center text-[9px] text-slate-400"><i class="fa-solid fa-users"></i></div>
                                                    @endif
                                                </div>
                                                <div class="flex-1 min-w-0">
                                                    <div class="flex justify-between items-center mb-0.5">
                                                        <p class="text-sm font-medium text-slate-200 truncate group-hover:text-blue-400 transition-colors">{{ $name }}</p>
                                                        @if($conv->lastMessage)
                                                            <p class="text-[10px] text-slate-400 ml-2">{{ $conv->lastMessage->sent_at->shortAbsoluteDiffForHumans() }}</p>
                                                        @endif
                                                    </div>
                                                    <div class="flex justify-between items-center">
                                                        <p class="text-[13px] text-slate-400 truncate pr-2">
                                                            @if($conv->lastMessage)
                                                                @if($conv->lastMessage->sender === auth()->user()->login)
                                                                    <span class="text-slate-500 mr-1"><i class="fa-solid fa-check-double text-[10px]"></i></span>
                                                                @endif
                                                                {{ $conv->lastMessage->body }}
                                                            @else
                                                                <span class="italic text-slate-500">Belum ada pesan</span>
                                                            @endif
                                                        </p>
                                                        @if($unread > 0)
                                                            <span class="inline-flex items-center justify-center px-1.5 py-0.5 min-w-[20px] rounded-full bg-blue-500 text-white text-[10px] font-bold">{{ $unread }}</span>
                                                        @endif
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    @empty
                                        <div class="flex flex-col items-center justify-center h-32 text-slate-500">
                                            <i class="fa-regular fa-comments text-2xl mb-2"></i>
                                            <p class="text-sm">Tidak ada percakapan.</p>
                                        </div>
                                    @endforelse
                                </ul>
                            </div>

                        <!-- MODE 2: CHAT ROOM -->
                        @elseif($mode === 'room' && $this->activeConversation)
                            @php
                                $roomName = $this->getConversationName($this->activeConversation);
                            @endphp
                            
                            <div class="px-4 py-3 bg-[#1f2742] shadow-md border-b border-slate-700 z-10 flex items-center justify-between">
                                <div class="flex items-center gap-3">
                                    <button wire:click="backToList" class="text-slate-400 hover:text-white transition-colors">
                                        <i class="fa-solid fa-arrow-left"></i>
                                    </button>
                                    <div class="w-9 h-9 rounded-full bg-slate-600 flex items-center justify-center text-white font-medium text-sm">
                                        {{ strtoupper(substr($roomName, 0, 1)) }}
                                    </div>
                                    <div>
                                        <h2 class="text-sm font-semibold text-white">{{ $roomName }}</h2>
                                        <div class="flex items-center gap-1.5">
                                            <div class="w-1.5 h-1.5 rounded-full bg-green-500"></div>
                                            <p class="text-[10px] text-slate-400">Online</p>
                                        </div>
                                    </div>
                                </div>
                                <button @click="chatOpen = false" class="text-slate-400 hover:text-white">
                                    <i class="fa-solid fa-xmark text-lg"></i>
                                </button>
                            </div>

                            <div x-ref="chatBody" class="flex-1 overflow-y-auto p-4 space-y-4 bg-[#0a1120] scrollbar-thin scrollbar-thumb-slate-700" wire:poll.3s="markAsRead({{ $this->activeConversationId }})">
                                @foreach($this->activeConversation->messages as $msg)
                                    @php $isMe = $msg->sender === auth()->user()->login; @endphp
                                    <div class="flex {{ $isMe ? 'justify-end' : 'justify-start' }}">
                                        <div class="max-w-[80%] flex flex-col {{ $isMe ? 'items-end' : 'items-start' }}">
                                            @if(!$isMe && $this->activeConversation->is_group)
                                                <span class="text-[10px] text-slate-400 mb-0.5 ml-1">{{ $msg->senderUser->name ?? $msg->sender }}</span>
                                            @endif
                                            <div class="{{ $isMe ? 'bg-blue-600 text-white rounded-l-xl rounded-tr-xl' : 'bg-[#1f2742] text-slate-200 border border-slate-700 rounded-r-xl rounded-tl-xl' }} px-3.5 py-2 shadow-sm text-[13px] leading-relaxed">
                                                {!! nl2br(e($msg->body)) !!}
                                            </div>
                                            <span class="text-[9px] text-slate-500 mt-1 {{ $isMe ? 'mr-1' : 'ml-1' }}">{{ $msg->sent_at->format('H:i') }}</span>
                                        </div>
                                    </div>
                                @endforeach
                            </div>

                            <div class="p-3 bg-[#1f2742] border-t border-slate-700">
                                <form wire:submit.prevent="sendMessage" class="flex items-end gap-2">
                                    <div class="flex-1 bg-[#101b30] rounded-lg border border-slate-600 overflow-hidden focus-within:border-blue-500 transition-all">
                                        <textarea 
                                            wire:model="messageBody" 
                                            class="w-full bg-transparent text-white p-2.5 text-[13px] focus:outline-none resize-none max-h-24 min-h-[40px] scrollbar-thin scrollbar-thumb-slate-700" 
                                            rows="1" 
                                            placeholder="Tulis pesan..."
                                            x-on:keydown.enter.prevent="if(!$event.shiftKey) { $wire.sendMessage() }"
                                        ></textarea>
                                    </div>
                                    <button type="submit" class="w-10 h-10 flex-shrink-0 bg-blue-600 hover:bg-blue-500 text-white rounded-lg flex items-center justify-center transition-colors shadow disabled:opacity-50" wire:loading.attr="disabled">
                                        <i class="fa-solid fa-paper-plane text-sm"></i>
                                    </button>
                                </form>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL CARI USER BARU -->
    @if($showNewChatModal)
    <div class="fixed inset-0 z-[60] flex items-center justify-center px-4" aria-modal="true">
        <div class="fixed inset-0 bg-slate-900/80 backdrop-blur-sm" wire:click="$set('showNewChatModal', false)"></div>
        <div class="bg-[#1f2742] w-full max-w-sm rounded-xl shadow-2xl border border-slate-700 z-10 overflow-hidden flex flex-col h-[60vh]">
            <div class="p-4 border-b border-slate-700 flex justify-between items-center bg-[#101b30]">
                <h3 class="text-white text-sm font-semibold">Mulai Obrolan Baru</h3>
                <button wire:click="$set('showNewChatModal', false)" class="text-slate-400 hover:text-white"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <div class="p-3 bg-[#1f2742]">
                <input wire:model.live.debounce.300ms="userSearchQuery" type="text" class="w-full bg-[#101b30] text-white border border-slate-600 rounded-lg py-2 px-3 focus:outline-none focus:border-blue-500 text-sm" placeholder="Cari nama atau username..." autofocus>
            </div>
            <div class="overflow-y-auto flex-1 p-2 scrollbar-thin">
                @if(strlen($userSearchQuery) > 0)
                    <ul class="space-y-1">
                        @forelse($this->availableUsers as $user)
                            <li>
                                <button wire:click="startDirectChat('{{ $user->login }}')" class="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-[#101b30] text-left transition-colors">
                                    <div class="w-8 h-8 rounded-full bg-slate-600 flex items-center justify-center text-white font-medium text-xs">
                                        {{ strtoupper(substr($user->name, 0, 1)) }}
                                    </div>
                                    <div>
                                        <p class="text-sm font-medium text-white">{{ $user->name }}</p>
                                        <p class="text-[11px] text-slate-400">{{ $user->login }}</p>
                                    </div>
                                </button>
                            </li>
                        @empty
                            <p class="text-center text-slate-500 text-xs py-4">Karyawan tidak ditemukan.</p>
                        @endforelse
                    </ul>
                @else
                    <p class="text-center text-slate-500 text-xs py-8">Ketik nama kolega...</p>
                @endif
            </div>
        </div>
    </div>
    @endif
</div>

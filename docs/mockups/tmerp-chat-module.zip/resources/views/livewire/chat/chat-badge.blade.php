<div wire:poll.10s="calculateUnread">
    @if($count > 0)
        <span class="absolute top-0 right-0 inline-flex items-center justify-center px-1.5 py-0.5 text-[9px] font-bold text-white bg-red-500 rounded-full transform translate-x-1/3 -translate-y-1/3">{{ $count }}</span>
    @endif
</div>
